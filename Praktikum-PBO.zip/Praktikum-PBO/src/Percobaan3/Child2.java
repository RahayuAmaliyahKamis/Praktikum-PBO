/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Percobaan3;

/**
 *
 * @author ASUS
 */
public class Child2 extends Parent2 {
    int x;
    
    // Konstruktor kelas Child2
    public Child2() {
        x = 5;
    }
}
