/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Percobaan8;

/**
 *
 * @author ASUS
 */
public class Parent3 {
    String parentName;
    Parent3(){}
    
    Parent3(String parentName){
        this.parentName = parentName;
        System.out.println("Konstruktor parent");
    }
}

class Baby extends Parent3 {
    String babyName;
    
    Baby(String babyName){
        super();
        this.babyName = babyName;
        System.out.println("Konstruktor Baby");
        System.out.println(babyName);
    }
    
    public void cry(){
        System.out.println("Owek owek");
    }
}